# CYPER DDOS Tool - By Xylays Developer

╭━━━┳╮╱╱╭┳╮╱╱╭┳━━━┳━━━╮  
┃╭━╮┃╰╮╭╯┃╰╮╭╯┃╭━╮┃╭━╮┃  
┃╰━╯┣╮╰╯╭┻╮╰╯╭┻╯╭╯┣╯╭╯┃  
┃╭╮╭╯╰╮╭╯╱╰╮╭╯╱╱┃╭╯╱┃╭╯  
┃┃┃╰╮╱┃┃╱╱╱┃┃╱╱╱┃┃╱╱┃┃  
╰╯╰━╯╱╰╯╱╱╱╰╯╱╱╱╰╯╱╱╰╯  

> **Project ini dibuat untuk pembelajaran keamanan server dan stress testing.**  
> Jangan digunakan untuk menyerang sistem tanpa izin!

---

# FITUR DDoS ☠️
- [x] UDP Flood
- [x] TCP Flood
- [x] HTTP GET Massive Flood
- [x] TCP SYN Flood (HandShake Killer)
- [x] HTTP POST Payload Bomb
- [x] Slowloris Infinite Connection Attack
- [x] ICMP Ping Smash
- [x] Random Packet 4096 Bytes Barrage
- [x] HTTP Header Overload (Header Spam)
- [x] RAW Octet Payload HTTP Attack
- [x] Domain to IP Checker
- [x] Real-time Packet Sent Statistics

---

# Cara Pakai  
1. Install `Python 3` (minimal).
2. Install dependensi:
    ```
    pip install requests
    ```
3. Jalankan file:
    ```
    python multiverse_ddos.py
    ```
4. Pilih metode serangan sesuai selera sadis lu (1-11).
5. Input IP/PORT/URL, jumlah packet, dan thread...  
6. **Tinggal liatin server target kejang-kejang.**

---

# Peringatan Keras
⚠️ **Script ini hanya untuk tujuan testing pribadi atau edukasi.**  
⚠️ **Penulis tidak bertanggung jawab atas penyalahgunaan alat ini.**  
⚠️ **Gunakan secara etis dan bertanggung jawab.**

---

# Credits  
- Developer: **Xylays Developer**  
- Telegram: [t.me/conquerryy](https://t.me/conquerryy)

**Multiverse will conquer the cyberworld.**  
© 2025 - Xylays Inclustries